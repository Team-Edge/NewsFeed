CREATE DATABASE  IF NOT EXISTS `Newsfeed` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `Newsfeed`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: www.occaso.me    Database: Newsfeed
-- ------------------------------------------------------
-- Server version	5.5.5-10.0.26-MariaDB-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Archive_CustomFeedEntry`
--

DROP TABLE IF EXISTS `Archive_CustomFeedEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Archive_CustomFeedEntry` (
  `Filter_ID` int(11) NOT NULL,
  `SourceFeedEntry_ID` int(11) NOT NULL,
  KEY `Archive_CustomFeedEntry_ibfk_2` (`SourceFeedEntry_ID`),
  KEY `Archive_CustomFeedEntry_ibfk_1_idx` (`Filter_ID`),
  CONSTRAINT `Archive_CustomFeedEntry_ibfk_1` FOREIGN KEY (`Filter_ID`) REFERENCES `Filter` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Archive_CustomFeedEntry_ibfk_2` FOREIGN KEY (`SourceFeedEntry_ID`) REFERENCES `Archive_SourceFeedEntry` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Archive_SourceFeedEntry`
--

DROP TABLE IF EXISTS `Archive_SourceFeedEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Archive_SourceFeedEntry` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SourceFeed_ID` int(11) NOT NULL,
  `Title` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Description` mediumtext NOT NULL,
  `Img_URL` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `PubDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `URL` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Text` longtext NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Archive_SourceFeedEntry_ibfk_1` (`SourceFeed_ID`),
  CONSTRAINT `Archive_SourceFeedEntry_ibfk_1` FOREIGN KEY (`SourceFeed_ID`) REFERENCES `SourceFeed` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21263 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CustomFeed`
--

DROP TABLE IF EXISTS `CustomFeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CustomFeed` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Newsletter` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `CustomFeed_ibfk_1` (`User_ID`),
  CONSTRAINT `CustomFeed_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `User` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CustomFeedEntry`
--

DROP TABLE IF EXISTS `CustomFeedEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CustomFeedEntry` (
  `Filter_ID` int(11) NOT NULL,
  `SourceFeedEntry_ID` int(11) NOT NULL,
  `Sent` tinyint(1) NOT NULL DEFAULT '0',
  `Showed` tinyint(1) NOT NULL DEFAULT '0',
  KEY `CustomFeedEntry_ibfk_2` (`SourceFeedEntry_ID`),
  KEY `CustomFeedEntry_ibfk_1_idx` (`Filter_ID`),
  CONSTRAINT `CustomFeedEntry_ibfk_1` FOREIGN KEY (`Filter_ID`) REFERENCES `Filter` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CustomFeedEntry_ibfk_2` FOREIGN KEY (`SourceFeedEntry_ID`) REFERENCES `SourceFeedEntry` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Filter`
--

DROP TABLE IF EXISTS `Filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Filter` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomFeed_ID` int(11) NOT NULL,
  `Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Filter_ibfk_1` (`CustomFeed_ID`),
  CONSTRAINT `Filter_ibfk_1` FOREIGN KEY (`CustomFeed_ID`) REFERENCES `CustomFeed` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FilterKeyword`
--

DROP TABLE IF EXISTS `FilterKeyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FilterKeyword` (
  `Filter_ID` int(11) NOT NULL,
  `Keyword` varchar(255) CHARACTER SET latin1 NOT NULL,
  `SearchIndex` int(11) NOT NULL,
  `Inverted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Filter_ID`,`Keyword`,`SearchIndex`,`Inverted`),
  CONSTRAINT `FilterKeyword_ibfk_1` FOREIGN KEY (`Filter_ID`) REFERENCES `Filter` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `FilterURL`
--

DROP TABLE IF EXISTS `FilterURL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FilterURL` (
  `Filter_ID` int(11) NOT NULL,
  `SourceFeed_ID` int(11) NOT NULL,
  PRIMARY KEY (`Filter_ID`,`SourceFeed_ID`),
  KEY `FilterURL_ibfk_2` (`SourceFeed_ID`),
  CONSTRAINT `FilterURL_ibfk_1` FOREIGN KEY (`Filter_ID`) REFERENCES `Filter` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FilterURL_ibfk_2` FOREIGN KEY (`SourceFeed_ID`) REFERENCES `SourceFeed` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Org_User`
--

DROP TABLE IF EXISTS `Org_User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Org_User` (
  `Org_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SourceFeed`
--

DROP TABLE IF EXISTS `SourceFeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SourceFeed` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `URL` varchar(255) CHARACTER SET latin1 NOT NULL,
  `CacheFile` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Title` varchar(255) CHARACTER SET latin1 NOT NULL,
  `TTL` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Filter_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Dumping data for table `SourceFeed`
--

LOCK TABLES `SourceFeed` WRITE;
/*!40000 ALTER TABLE `SourceFeed` DISABLE KEYS */;
INSERT INTO `SourceFeed` 
VALUES (1,'http://www.tagesschau.de/xml/rss2','./Caches/Cache1.txt','Tagesschau',60,0,0),
		(2,'http://rss.focus.de/fol/XML/rss_folnews.xml','./Caches/Cache2.txt','Focus Online',60,0,0),
		(7,'http://www.welt.de/?service=Rss','./Caches/Cache7.txt','Die Welt',120,0,0),
		(8,'http://www.t-online.de/themen/rss/','./Caches/Cache8.txt','T-Online',120,0,0),
		(9,'http://www.spiegel.de/schlagzeilen/index.rss','./Caches/Cache9.txt','Spiegel Online',120,0,0),
		(10,'http://www.stern.de/feed/standard/all/','./Caches/Cache10.txt','Stern',120,0,0),
		(11,'http://www.stuttgarter-zeitung.de/news.rss.feed','./Caches/Cache11.txt','Stuttgarter Zeitung',120,0,0),
		(12,'http://rss.kicker.de/news/aktuell','./Caches/Cache12.txt','Kicker',120,0,0),
		(13,'http://www.bild.de/rssfeeds/vw-alles/vw-alles-26970192,sort=1,view=rss2.bild.xml','./Caches/Cache13.txt','Bild Zeitung',120,0,0),
		(14,'http://www.heute-show.de/zdf/rss.xml','./Caches/Cache14.txt','Heute Show ZDF',120,0,0);
/*!40000 ALTER TABLE `SourceFeed` ENABLE KEYS */;
UNLOCK TABLES;



--
-- Table structure for table `SourceFeedEntry`
--

DROP TABLE IF EXISTS `SourceFeedEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SourceFeedEntry` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SourceFeed_ID` int(11) NOT NULL,
  `Title` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Description` mediumtext NOT NULL,
  `Img_URL` varchar(512) CHARACTER SET latin1 DEFAULT NULL,
  `PubDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `URL` varchar(512) CHARACTER SET latin1 NOT NULL,
  `Text` longtext NOT NULL,
  `toRemove` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SourceFeedEntry_ibfk_1` (`SourceFeed_ID`),
  CONSTRAINT `SourceFeedEntry_ibfk_1` FOREIGN KEY (`SourceFeed_ID`) REFERENCES `SourceFeed` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21409 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Edge`@`%`*/ /*!50003 TRIGGER `Newsfeed`.`SourceFeedEntry_BEFORE_DELETE` BEFORE DELETE ON `SourceFeedEntry` FOR EACH ROW
BEGIN

INSERT INTO Archive_SourceFeedEntry(ID, SourceFeed_ID, Title, Description, Img_URL, PubDate, URL, `Text`) 
VALUES (OLD.ID, OLD.SourceFeed_ID, OLD.Title, OLD.Description, OLD.Img_URL, OLD.PubDate, OLD.URL, OLD.`Text`);

INSERT INTO Archive_CustomFeedEntry(Filter_ID, SourceFeedEntry_ID)
SELECT Filter_ID, SourceFeedEntry_ID FROM CustomFeedEntry 
WHERE SourceFeedEntry_ID = OLD.ID;

#DELETE FROM CustomFeedEntry WHERE SourceFeedEntry_ID = OLD.ID;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) CHARACTER SET latin1 NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `mail` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `Organisation` int(11) NOT NULL,
  `Organisations_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'Newsfeed'
--

--
-- Dumping routines for database 'Newsfeed'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-11 10:18:30
