<?php
require '../phpmailer/PHPMailerAutoload.php';

//Create a new PHPMailer instance
$mail = new PHPMailer;

$mail->IsSMTP();
$mail->Host = "smtp.gmail.com";

// optional
// used only when SMTP requires authentication  
$mail->SMTPAuth = true;
$mail->Username = 'TeamEdgeNF@gmail.com';
$mail->Password = 'TeamEdgePW';

//Für Umlaute
$mail->CharSet = 'utf-8'; 
//Set who the message is to be sent from
$mail->setFrom($mail->Username, "Team Edge Newsfeed");

include("../zugriff.php");
if ($mysqli->connect_error) {
$message['error'] = 'Datenbankverbindung fehlgeschlagen: ' . $mysqli->connect_error;
}
$stmt=$mysqli->prepare("SELECT * FROM User WHERE 1=?");
$stmt->bind_param('i',$send);


$send='1';
$stmt->execute();
$result = $stmt->get_result();
//Alle User
foreach($result as $row){
$allempty=0;
$allprofiles=0;

$text="<div style='background:#e6e6e6;border:3px solid black;padding:20px;'>";

$stmt=$mysqli->prepare("SELECT * FROM CustomFeed WHERE CustomFeed.User_ID=? or CustomFeed.User_ID=(Select Org_ID FROM Org_User Where Org_User.User_ID=?)");
$stmt->bind_param('ii',$uid,$uid);


$uid=$row['ID'];
$stmt->execute();
$result = $stmt->get_result();
//Alle Profile pro User
foreach($result as $row2){
if($row2['Newsletter']==0){
$size=0;
$text.= "<h1 style='font-size:30px;'>Profil: ".$row2['Name']."</h1>";
$stmt=$mysqli->prepare("SELECT article.ID, entry.Filter_ID FROM SourceFeedEntry article INNER JOIN CustomFeedEntry entry ON entry.SourceFeedEntry_ID = article.ID INNER JOIN Filter filt ON entry.Filter_ID = filt.ID INNER JOIN CustomFeed prof ON filt.CustomFeed_ID = prof.ID WHERE prof.ID= ? ORDER BY article.ID DESC");
$stmt->bind_param('i',$pid);


$pid=$row2['ID'];
$stmt->execute();
$result = $stmt->get_result();
print "\n\n";
//Alle Artikel pro Profil
foreach ($result as $row3){




$SQL="SELECT SourceFeedEntry.Title as t1,SourceFeed.Title as t2,SourceFeedEntry.URL as URL,Img_URL,PubDate,Description, CustomFeedEntry.Sent FROM SourceFeedEntry,SourceFeed,CustomFeedEntry WHERE SourceFeedEntry.ID=".$row3['ID']." AND SourceFeedEntry.SourceFeed_ID=SourceFeed.ID AND CustomFeedEntry.SourceFeedEntry_ID=SourceFeedEntry.ID AND CustomFeedEntry.Filter_ID=".$row3['Filter_ID']; 
//Artikel Inhalt
foreach ($mysqli->query($SQL) as $row4){
	if(count($row4)!=0 and $row4['Sent']==0){
		$size++;
	}
if($row4['Sent']==0){	
$text.="<a href='".$row4['URL']."' style='color:black;font-size:20px;'><b>".$row4['t1']."</b></a><br><p style='font-size:15px;'>".$row4['Description']."</p>";
$SQL="UPDATE CustomFeedEntry, SourceFeedEntry, SourceFeed SET CustomFeedEntry.Sent=1 WHERE SourceFeedEntry.ID=".$row3['ID']." AND SourceFeedEntry.SourceFeed_ID=SourceFeed.ID AND CustomFeedEntry.SourceFeedEntry_ID=SourceFeedEntry.ID AND CustomFeedEntry.Filter_ID=".$row3['Filter_ID'];
$mysqli->query($SQL);
}



}
}
$allprofiles++;
if($size ==0){
	$allempty++;
	$text.='Keine neuen Artikel vorhanden';
}

}
else{
	$stmt=$mysqli->prepare("SELECT article.ID, entry.Filter_ID FROM SourceFeedEntry article INNER JOIN CustomFeedEntry entry ON entry.SourceFeedEntry_ID = article.ID INNER JOIN Filter filt ON entry.Filter_ID = filt.ID INNER JOIN CustomFeed prof ON filt.CustomFeed_ID = prof.ID WHERE prof.ID= ? ORDER BY article.ID DESC");
$stmt->bind_param('i',$pid);


$pid=$row2['ID'];
$stmt->execute();
$result = $stmt->get_result();
//Alle Artikel pro Profil
foreach ($result as $row3){
	$SQL="UPDATE CustomFeedEntry, SourceFeedEntry, SourceFeed SET CustomFeedEntry.Sent=1 WHERE SourceFeedEntry.ID=".$row3['ID']." AND SourceFeedEntry.SourceFeed_ID=SourceFeed.ID AND CustomFeedEntry.SourceFeedEntry_ID=SourceFeedEntry.ID AND CustomFeedEntry.Filter_ID=".$row3['Filter_ID'];
	$mysqli->query($SQL);
}
	
}

}




if($allprofiles!=$allempty){
//clear previous Recipients
$mail->ClearAllRecipients( );
//Set who the message is to be sent to
$mail->addAddress($row['mail']);
//Set the subject line
$mail->Subject = "Daily News";
 

 $mail->IsHTML(true); //Versand im HTML-Format festlegen
$text.="</div>";
$mail->Body=nl2br($text);



//send the message, check for errors

if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "<p>Nachricht gesendet!</p>";
}
}

}

?>
